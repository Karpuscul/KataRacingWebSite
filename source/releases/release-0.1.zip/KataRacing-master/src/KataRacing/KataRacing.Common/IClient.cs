﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KataRacing.Common
{
    /// <summary>
    /// Создал интерфейс, пока хз что в нем должно быть
    /// </summary>
    public interface IClient
    {
    }
}
