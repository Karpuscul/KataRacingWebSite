KataRacing
==========

Kata Racing is a multiplayer racing game being developed on .Net technology stack and deployed to Web, Android, iOS and Windows Phone platforms.